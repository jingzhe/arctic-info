pluginManagement {
    repositories {
        gradlePluginPortal()
    }
}
rootProject.name = "arctic"
