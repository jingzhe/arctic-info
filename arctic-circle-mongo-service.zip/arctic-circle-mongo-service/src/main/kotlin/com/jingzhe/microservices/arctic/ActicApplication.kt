package com.jingzhe.microservices.arctic

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class ArcticApplication

fun main(args: Array<String>) {
    runApplication<ArcticApplication>(*args)
}
