package com.jingzhe.microservices.arctic.exception

class InvalidInputException(msg: String) : RuntimeException(msg)
