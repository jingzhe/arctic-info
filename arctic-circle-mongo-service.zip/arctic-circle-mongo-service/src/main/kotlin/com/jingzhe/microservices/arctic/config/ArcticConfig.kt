package com.jingzhe.microservices.arctic.config

import org.springframework.context.annotation.Configuration
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories
import org.springframework.data.mongodb.repository.config.EnableReactiveMongoRepositories

@Configuration
@EnableMongoRepositories(basePackages = ["com.jingzhe.microservices.arctic.repository"])
class ArcticConfig
