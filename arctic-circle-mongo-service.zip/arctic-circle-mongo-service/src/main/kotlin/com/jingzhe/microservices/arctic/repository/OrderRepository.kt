package com.jingzhe.microservices.arctic.repository

import com.jingzhe.microservices.arctic.entity.OrderSummaryVO
import org.springframework.data.repository.kotlin.CoroutineCrudRepository

interface OrderRepository: CoroutineCrudRepository<OrderSummaryVO, String>
