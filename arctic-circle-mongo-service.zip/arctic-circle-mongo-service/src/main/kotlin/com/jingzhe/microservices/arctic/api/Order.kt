package com.jingzhe.microservices.arctic.api

import com.fasterxml.jackson.databind.PropertyNamingStrategies
import com.fasterxml.jackson.databind.annotation.JsonNaming


@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy::class)
data class Order (
    val deviceIdentifier: String,
    val ipAddress: String? = null,
    val longitude: Double? = null,
    val latitude: Double? = null,
    val reference: String? = null,
    val product: String? = null,
    val orderDesc: String? = null,
    val customer: String? = null
)
