package com.jingzhe.microservices.arctic.controllers

import com.jingzhe.microservices.arctic.api.Order
import com.jingzhe.microservices.arctic.api.ArcticEndpoint
import com.jingzhe.microservices.arctic.api.Device
import com.jingzhe.microservices.arctic.services.DataService
import mu.KotlinLogging
import org.springframework.web.bind.annotation.RestController

private val logger = KotlinLogging.logger {}

@RestController
class ArcticController(
    private val dataService: DataService,
) : ArcticEndpoint {

    override suspend fun createOrder(order: Order): String {
        val res =  dataService.createOrder(order)
        logger.info { "OrderId $res is stored in database" }
        return res
    }

    override suspend fun createDevice(device: Device): String {
        val res = dataService.createDevice(device)
        logger.info { "Device identifier $res is created in database" }
        return res
    }

}
