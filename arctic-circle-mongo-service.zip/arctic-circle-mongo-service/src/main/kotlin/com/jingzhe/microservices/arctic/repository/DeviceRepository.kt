package com.jingzhe.microservices.arctic.repository

import com.jingzhe.microservices.arctic.entity.DeviceVO
import kotlinx.coroutines.flow.Flow
import org.springframework.data.repository.kotlin.CoroutineCrudRepository

interface DeviceRepository: CoroutineCrudRepository<DeviceVO, String> {
    fun findByIdentifier(identifier: String): Flow<DeviceVO>
    fun findByIdentifierAndStatus(identifier: String, status: String): Flow<DeviceVO>
}
