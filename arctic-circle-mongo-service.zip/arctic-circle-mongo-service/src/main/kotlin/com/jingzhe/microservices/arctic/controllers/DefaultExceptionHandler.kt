package com.jingzhe.microservices.arctic.controllers

import com.jingzhe.microservices.arctic.exception.InvalidInputException
import mu.KotlinLogging
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.ControllerAdvice
import org.springframework.web.bind.annotation.ExceptionHandler

class ErrorMessageModel(
    val status: Int? = null,
    val message: String? = null
)

private val logger = KotlinLogging.logger {}

@ControllerAdvice
class DefaultExceptionHandler {

    @ExceptionHandler(
        value = [
            IllegalArgumentException::class,
            InvalidInputException::class
        ]
    )
    fun handleInvalidParameterException(ex: RuntimeException): ResponseEntity<ErrorMessageModel> {
        val errorMessage = ErrorMessageModel(HttpStatus.BAD_REQUEST.value(), ex.message)
        logger.warn { "Invalid request: ${errorMessage.message}" }
        return ResponseEntity(errorMessage, HttpStatus.BAD_REQUEST)
    }
}
