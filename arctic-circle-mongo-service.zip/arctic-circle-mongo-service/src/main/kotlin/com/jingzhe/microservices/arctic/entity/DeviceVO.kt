package com.jingzhe.microservices.arctic.entity

import org.springframework.data.annotation.Id
import org.springframework.data.mongodb.core.mapping.Document

@Document("devices")
data class DeviceVO (
    @Id val id: String? = null,
    val identifier: String,
    val serial: String,
    val name: String? = null,
    val longitude: Double? = null,
    val latitude: Double? = null,
    val company: String? = null,
    val address: String? = null,
    val country: String? = null,
    val status: String? = null,

)
