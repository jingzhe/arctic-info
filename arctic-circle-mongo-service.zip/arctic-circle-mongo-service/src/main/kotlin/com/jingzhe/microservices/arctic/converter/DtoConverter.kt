package com.jingzhe.microservices.arctic.converter

import com.jingzhe.microservices.arctic.api.Device
import com.jingzhe.microservices.arctic.api.DeviceStatus
import com.jingzhe.microservices.arctic.api.Order
import com.jingzhe.microservices.arctic.entity.DeviceVO
import com.jingzhe.microservices.arctic.entity.OrderSummaryVO

private const val orderPrefix = "MYT-"

fun toOrderVO(order: Order, deviceId: String): OrderSummaryVO {
    val orderId = orderPrefix + order.reference?.substringAfter(orderPrefix)?.substringBefore("\n")
    return OrderSummaryVO(
        orderId = orderId,
        deviceId = deviceId,
        ipAddress = order.ipAddress,
        reference = order.reference,
        product = order.product,
        orderDesc = order.orderDesc,
        customer = order.customer
    )
}

fun toDeviceVO(device: Device): DeviceVO = DeviceVO(
    identifier = device.identifier,
    serial = device.serial,
    name = device.name,
    longitude = device.longitude,
    latitude = device.latitude,
    company = device.company,
    address = device.address,
    country = device.country,
    status = DeviceStatus.ACTIVE.value
)
