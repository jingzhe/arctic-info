package com.jingzhe.microservices.arctic.api

import com.fasterxml.jackson.databind.PropertyNamingStrategies
import com.fasterxml.jackson.databind.annotation.JsonNaming

enum class DeviceStatus(val value: String) {
    ACTIVE("ACTIVE"),
    DISABLED("DISABLED")
}

@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy::class)
data class Device (
    val identifier: String,
    val serial: String,
    val name: String? = null,
    val longitude: Double? = null,
    val latitude: Double? = null,
    val company: String? = null,
    val address: String? = null,
    val country: String? = null
)
