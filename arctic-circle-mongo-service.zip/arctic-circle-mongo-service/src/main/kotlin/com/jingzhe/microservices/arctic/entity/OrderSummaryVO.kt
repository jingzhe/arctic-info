package com.jingzhe.microservices.arctic.entity

import org.springframework.data.annotation.Id
import org.springframework.data.mongodb.core.mapping.Document

@Document("orders")
data class OrderSummaryVO (
    @Id val id: String? = null,
    val orderId: String? = null,
    val deviceId: String,
    val ipAddress: String? = null,
    val longitude: Double? = null,
    val latitude: Double? = null,
    val cost: Double? = null,
    val currency: String? = null,
    val reference: String? = null,
    val product: String? = null,
    val orderDesc: String? = null,
    val customer: String? = null
)
