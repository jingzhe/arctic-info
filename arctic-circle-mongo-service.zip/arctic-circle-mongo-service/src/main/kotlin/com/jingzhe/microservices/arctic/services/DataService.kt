package com.jingzhe.microservices.arctic.services

import com.jingzhe.microservices.arctic.api.Device
import com.jingzhe.microservices.arctic.api.DeviceStatus
import com.jingzhe.microservices.arctic.api.Order
import com.jingzhe.microservices.arctic.converter.toDeviceVO
import com.jingzhe.microservices.arctic.converter.toOrderVO
import com.jingzhe.microservices.arctic.entity.DeviceVO
import com.jingzhe.microservices.arctic.repository.DeviceRepository

import com.jingzhe.microservices.arctic.repository.OrderRepository
import kotlinx.coroutines.flow.toList
import mu.KotlinLogging
import org.springframework.stereotype.Service

private val logger = KotlinLogging.logger {}

@Service
class DataService(
    private val orderRepository: OrderRepository,
    private val deviceRepository: DeviceRepository) {

    suspend fun createOrder(order: Order): String {
        val devices = deviceRepository.findByIdentifierAndStatus(order.deviceIdentifier, DeviceStatus.ACTIVE.value).toList()
        val deviceId = if (devices.isEmpty()) {
            val deviceVO = DeviceVO(
                identifier = order.deviceIdentifier,
                serial = "empty_serial",
                name = "Created_live",
                status = DeviceStatus.ACTIVE.value
            )
            deviceRepository.save(deviceVO).id
        } else {
            devices.first().id
        }
        val orderVO = toOrderVO(order, deviceId!!)
        return orderRepository.save(orderVO).orderId ?: "unknown"
    }

    suspend fun createDevice(device: Device): String {
        val list = deviceRepository.findByIdentifierAndStatus(device.identifier, DeviceStatus.ACTIVE.value).toList()
            .map { it.copy(status = DeviceStatus.DISABLED.value) }
        deviceRepository.saveAll(list).toList()

        val deviceVO = toDeviceVO(device)
        return deviceRepository.save(deviceVO).identifier
    }
}

