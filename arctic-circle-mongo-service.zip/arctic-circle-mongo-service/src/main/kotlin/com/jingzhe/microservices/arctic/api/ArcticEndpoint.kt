package com.jingzhe.microservices.arctic.api

import io.swagger.v3.oas.annotations.Operation
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping


@RequestMapping("/arctic")
interface ArcticEndpoint {

    @Operation(
        summary = "Create an order summary",
        description = "Create an order summary"
    )
    @PostMapping("order-summary")
    suspend fun createOrder(
        @RequestBody order: Order): String

    @Operation(
        summary = "Create a device",
        description = "Create a device"
    )
    @PostMapping("devices")
    suspend fun createDevice(
        @RequestBody device: Device): String

}
