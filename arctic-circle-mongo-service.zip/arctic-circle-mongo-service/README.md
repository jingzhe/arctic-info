# README #

This README would normally document whatever steps are necessary to get your application up and running.

psql -U postgres

postgres=# create USER arctic_tester with PASSWORD 'arctic_password';
postgres=# create DATABASE arctic_db;
postgres=# GRANT CONNECT ON DATABASE arctic_db TO arctic_tester;
postgres=# GRANT ALL PRIVILEGES ON SCHEMA public TO arctic_tester;

postgres=# create USER user_384345 with PASSWORD 'EDCVFTG';
postgres=# create DATABASE arctic_db;
postgres=# GRANT CONNECT ON DATABASE arctic_db TO user_384345;
postgres=# GRANT ALL PRIVILEGES ON SCHEMA public TO user_384345;

psql --host=arctic-db-instance.cyjhe0jq7hru.eu-north-1.rds.amazonaws.com --port=5432 --username=postgres --password --dbname=arctic_db

