import { Construct } from 'constructs';
import {App, Chart, ChartProps, Size} from 'cdk8s';
import {Environment, MicroService} from '@skenariolabs/cdk8s';
import {Cpu} from "cdk8s-plus-25";

function getResourceConfig(env: Environment) {
  switch (env) {
    case Environment.TEST:
      return {
        replicas: 1,
        resources: {
          memory: {
            request: Size.mebibytes(1000)
          },
          cpu: {
            request: Cpu.millis(1000)
          },
        },
      };
    case Environment.STAGING:
      return {
        replicas: 1,
        resources: {
          memory: {
            request: Size.mebibytes(1000)
          },
          cpu: {
            request: Cpu.millis(1000)
          },
        },
      };
    case Environment.PRODUCTION:
      return {
        replicas: 2,
        resources: {
          memory: {
            request: Size.mebibytes(2000)
          },
          cpu: {
            request: Cpu.millis(2000)
          },
        },
      };
    default:
      throw new Error('No specific environment provided.');
  }
}

const currentEnvironment: Environment = process.env.APP_ENV as Environment;

const envConfig = getResourceConfig(currentEnvironment);
export class MyChart extends Chart {
  constructor(scope: Construct, id: string, props: ChartProps = { }) {
    super(scope, id, props);

    // define resources here
    new MicroService(this, 'service', {
      name: 'property-microservice',
      resources: envConfig.resources,
      replicas: envConfig.replicas
    });
  }
}

const app = new App();
new MyChart(app, 'cdk8s')
app.synth();
